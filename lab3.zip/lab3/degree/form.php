<form action="check.php" method="POST">
	<fieldset>
		<legend>NAME</legend>
		<input style="width:30px" type="checkbox" name="ssc" value="ssc">ssc
		<input style="width:30px" type="checkbox" name="hsc" value="hsc">hsc
		<input style="width:30px" type="checkbox" name="msc" value="msc">msc
		<input style="width:30px" type="checkbox" name="bsc" value="bsc">bsc
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>