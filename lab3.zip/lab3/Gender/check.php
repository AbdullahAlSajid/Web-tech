<?php
if(isset($_POST['male']))
	echo $_POST['male'];

if(isset($_POST['female']))
	echo $_POST['female'];

if(isset($_POST['other']))
	echo $_POST['other'];
?>