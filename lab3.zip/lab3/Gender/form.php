<form action="check.php" method="POST">
	<fieldset>
		<legend>NAME</legend>
		<input style="width:30px" type="radio" name="male" value="male">male
		<input style="width:30px" type="radio" name="female" value="female">female
		<input style="width:30px" type="radio" name="other" value="other">other
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>