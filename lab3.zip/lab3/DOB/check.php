<?php
if(isset($_POST['day']))
	echo $_POST['day'];
echo " /";
if(isset($_POST['month']))
	echo $_POST['month'];
echo " /";
if(isset($_POST['year']))
	echo $_POST['year'];
?>