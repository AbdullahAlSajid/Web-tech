<form action="check.php" method="POST">
	<fieldset>
		<legend>NAME</legend>
		<p> format: dd  mm yy</p>
		<input style="width:30px" type="text" name="day" value="<?php if(isset($_POST['name']))echo $_POST['name']?>"><b> /</b>
		<input style="width:30px" type="text" name="month" value="<?php if(isset($_POST['name']))echo $_POST['name']?>"><b> /</b>
		<input style="width:30px" type="text" name="year" value="<?php if(isset($_POST['name']))echo $_POST['name']?>">
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>