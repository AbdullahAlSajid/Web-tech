<form action="check.php" method="POST">
	<fieldset>
		<legend>NAME</legend>
		  <select name="BG">
    <option value="A">A</option>
    <option value="A+">A+</option>
    <option value="B">B</option>
    <option value="B+">B+</option>
  </select>
  <input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>