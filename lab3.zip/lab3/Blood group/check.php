<?php
if(isset($_POST['BG'] == "A"))
	echo $_POST['A'];

if(isset($_POST['BG'] == A+))
	echo $_POST['A+'];

if(isset($_POST['BG']))
	echo $_POST['B'];

if(isset($_POST['BG']))
	echo $_POST['B+'];
?>