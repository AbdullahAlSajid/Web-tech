<?php
error_reporting(0);
if(count($_POST['degree'])>=2)
    echo "submitted";
else
    echo "please select at least two "

?>

<form action="#" method="POST">
	<fieldset>
        <legend>NAME</legend>
		<input style="width:30px" type="checkbox" name="degree[]" value="ssc">ssc
		<input style="width:30px" type="checkbox" name="degree[]" value="hsc">hsc
		<input style="width:30px" type="checkbox" name="degree[]" value="msc">msc
		<input style="width:30px" type="checkbox" name="degree[]" value="bsc">bsc
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>