<?php
if(!isset($_POST["bg"]) || ($_POST["bg"] == "0")) {echo "please select one";}
else
    echo "submitted";
?>
<form action="#" method="POST">
	<fieldset>
		<legend>NAME</legend>
		  <select name="bg">
            <option value="0">select</option> 
            <option value="A">A</option>
            <option value="A+">A+</option>
            <option value="B">B</option>
            <option value="B+">B+</option>
  </select>
  <input type="submit" name="submit" value="submit" >
		<hr/>
	</fieldset>
</form>